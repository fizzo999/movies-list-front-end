import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';

export class AboutMoviesListComponent extends Component {
  render() {
    return (
      <Container fluid='md' maxwidth='sm'>
        <div>AboutMoviesListComponent</div>
      </Container>
    );
  }
}

export default AboutMoviesListComponent;
